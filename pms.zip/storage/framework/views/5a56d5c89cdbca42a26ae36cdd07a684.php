

<?php $__env->startSection('title', 'Edit Service'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            
            <!-- Display Validation Errors -->
            <?php echo $__env->make('store.layouts.error', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0">Edit Service: <?php echo e($service->name); ?></h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('store.services.update', $service)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="name" class="form-label">Service Name *</label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="name" name="name" value="<?php echo e(old('name', $service->name)); ?>" required>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3">
                                    <label for="category" class="form-label">Category *</label>
                                    <select class="form-control <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            id="category" name="category" required>
                                        <option value="">Select Category</option>
                                        <option value="hair" <?php echo e(old('category', $service->category) == 'hair' ? 'selected' : ''); ?>>Hair Cut & Styling</option>
                                        <option value="coloring" <?php echo e(old('category', $service->category) == 'coloring' ? 'selected' : ''); ?>>Hair Coloring</option>
                                        <option value="beard" <?php echo e(old('category', $service->category) == 'beard' ? 'selected' : ''); ?>>Beard Services</option>
                                        <option value="spa" <?php echo e(old('category', $service->category) == 'spa' ? 'selected' : ''); ?>>Spa & Facial</option>
                                        <option value="massage" <?php echo e(old('category', $service->category) == 'massage' ? 'selected' : ''); ?>>Massage</option>
                                        <option value="waxing" <?php echo e(old('category', $service->category) == 'waxing' ? 'selected' : ''); ?>>Waxing</option>
                                        <option value="other" <?php echo e(old('category', $service->category) == 'other' ? 'selected' : ''); ?>>Other</option>
                                    </select>
                                    <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3">
                                    <label for="price" class="form-label">Price ($) *</label>
                                    <input type="number" step="0.01" min="0" 
                                           class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                           id="price" name="price" value="<?php echo e(old('price', $service->price)); ?>" required>
                                    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3">
                                    <label for="duration_minutes" class="form-label">Duration (minutes) *</label>
                                    <select class="form-control <?php $__errorArgs = ['duration_minutes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            id="duration_minutes" name="duration_minutes" required>
                                        <option value="">Select Duration</option>
                                        <option value="15" <?php echo e(old('duration_minutes', $service->duration_minutes) == '15' ? 'selected' : ''); ?>>15 minutes</option>
                                        <option value="30" <?php echo e(old('duration_minutes', $service->duration_minutes) == '30' ? 'selected' : ''); ?>>30 minutes</option>
                                        <option value="45" <?php echo e(old('duration_minutes', $service->duration_minutes) == '45' ? 'selected' : ''); ?>>45 minutes</option>
                                        <option value="60" <?php echo e(old('duration_minutes', $service->duration_minutes) == '60' ? 'selected' : ''); ?>>1 hour</option>
                                        <option value="90" <?php echo e(old('duration_minutes', $service->duration_minutes) == '90' ? 'selected' : ''); ?>>1.5 hours</option>
                                        <option value="120" <?php echo e(old('duration_minutes', $service->duration_minutes) == '120' ? 'selected' : ''); ?>>2 hours</option>
                                        <option value="180" <?php echo e(old('duration_minutes', $service->duration_minutes) == '180' ? 'selected' : ''); ?>>3 hours</option>
                                    </select>
                                    <?php $__errorArgs = ['duration_minutes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="description" class="form-label">Description</label>
                                    <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                              id="description" name="description" rows="8" 
                                              placeholder="Describe the service in detail..."><?php echo e(old('description', $service->description)); ?></textarea>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3">
                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="1" 
                                            <?php echo e(old('is_active', $service->is_active) ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="is_active">
                                            Service is active and available for booking
                                        </label>
                                    </div>
                                </div>

                                <!-- Service Statistics -->
                                <div class="card bg-light">
                                    <div class="card-body">
                                        <h6 class="card-title">Service Statistics</h6>
                                        <div class="row">
                                            <div class="col-6">
                                                <small class="text-muted">Total Employees</small>
                                                <div class="h5"><?php echo e($service->employees()->count()); ?></div>
                                            </div>
                                            <div class="col-6">
                                                <small class="text-muted">Created</small>
                                                <div class="h6"><?php echo e($service->created_at->format('M d, Y')); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary">Update Service</button>
                            <a href="<?php echo e(route('store.services.index')); ?>" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Add real-time duration display
    const durationSelect = document.getElementById('duration_minutes');
    const durationDisplay = document.createElement('div');
    durationDisplay.className = 'form-text mt-1';
    durationSelect.parentNode.appendChild(durationDisplay);

    function updateDurationDisplay() {
        const minutes = parseInt(durationSelect.value);
        if (minutes) {
            const hours = Math.floor(minutes / 60);
            const remainingMinutes = minutes % 60;
            
            if (hours > 0) {
                durationDisplay.textContent = `${hours} hour${hours > 1 ? 's' : ''}${remainingMinutes > 0 ? ` and ${remainingMinutes} minute${remainingMinutes > 1 ? 's' : ''}` : ''}`;
            } else {
                durationDisplay.textContent = `${minutes} minute${minutes > 1 ? 's' : ''}`;
            }
        } else {
            durationDisplay.textContent = '';
        }
    }

    durationSelect.addEventListener('change', updateDurationDisplay);
    updateDurationDisplay(); // Initial call
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('store.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\barbar\barbarshop\resources\views/store/services/edit.blade.php ENDPATH**/ ?>