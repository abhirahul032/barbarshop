@extends('admin.layouts.app')

@section('title', 'Dashboard')

@section('content')
    <h3>Welcome, Admin!</h3>
    <p>Your admin dashboard is ready.</p>
@endsection
