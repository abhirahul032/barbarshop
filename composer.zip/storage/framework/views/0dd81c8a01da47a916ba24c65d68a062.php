

<?php $__env->startSection('title', 'Business Types'); ?>

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between mb-3">
    <h4>Business Types</h4>
    <a href="<?php echo e(route('admin.business-type.create')); ?>" class="btn btn-dark">Add Business Type</a>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<!-- Search and Filter Form -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('admin.business-type.index')); ?>">
            <div class="row">
                <div class="col-md-6">
                    <div class="input-group">
                        <input type="text" name="search" class="form-control" placeholder="Search by name or description..." 
                               value="<?php echo e(request('search')); ?>">
                        <button class="btn btn-outline-secondary" type="submit">Search</button>
                        <?php if(request('search') || request('status') !== ''): ?>
                            <a href="<?php echo e(route('admin.business-type.index')); ?>" class="btn btn-outline-danger">Clear</a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <select name="status" class="form-control" onchange="this.form.submit()">
                        <option value="">All Status</option>
                        <option value="1" <?php echo e(request('status') === '1' ? 'selected' : ''); ?>>Active</option>
                        <option value="0" <?php echo e(request('status') === '0' ? 'selected' : ''); ?>>Inactive</option>
                    </select>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <table class="table table-bordered table-striped">
            <thead>
            <tr>
                <th>
                    <a href="<?php echo e(route('admin.business-type.index', [
                        'search' => request('search'),
                        'status' => request('status'),
                        'sort' => 'id', 
                        'direction' => ($sortField == 'id' && $sortDirection == 'asc') ? 'desc' : 'asc'
                    ])); ?>">
                        ID 
                        <?php if($sortField == 'id'): ?>
                            <?php echo $sortDirection == 'asc' ? '&#9650;' : '&#9660;'; ?>

                        <?php endif; ?>
                    </a>
                </th>
                <th>
                    <a href="<?php echo e(route('admin.business-type.index', [
                        'search' => request('search'),
                        'status' => request('status'),
                        'sort' => 'name', 
                        'direction' => ($sortField == 'name' && $sortDirection == 'asc') ? 'desc' : 'asc'
                    ])); ?>">
                        Name 
                        <?php if($sortField == 'name'): ?>
                            <?php echo $sortDirection == 'asc' ? '&#9650;' : '&#9660;'; ?>

                        <?php endif; ?>
                    </a>
                </th>
                <th>Description</th>
                <th>
                    <a href="<?php echo e(route('admin.business-type.index', [
                        'search' => request('search'),
                        'status' => request('status'),
                        'sort' => 'is_active', 
                        'direction' => ($sortField == 'is_active' && $sortDirection == 'asc') ? 'desc' : 'asc'
                    ])); ?>">
                        Status 
                        <?php if($sortField == 'is_active'): ?>
                            <?php echo $sortDirection == 'asc' ? '&#9650;' : '&#9660;'; ?>

                        <?php endif; ?>
                    </a>
                </th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $businessTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($type->id); ?></td>
                    <td><?php echo e($type->name); ?></td>
                    <td><?php echo e(Str::limit($type->description, 50)); ?></td>
                    <td>
                        <?php if($type->is_active): ?>
                            <span class="badge bg-success">Active</span>
                        <?php else: ?>
                            <span class="badge bg-danger">Inactive</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="btn-group" role="group">
                            <a href="<?php echo e(route('admin.business-type.show', $type->id)); ?>" class=""><i class="ri-eye-fill align-bottom me-2 text-muted"></i></a>
                            <a href="<?php echo e(route('admin.business-type.edit', $type->id)); ?>" class=""><i class="ri-pencil-fill align-bottom me-2 text-muted"></i></a>
                            <form action="<?php echo e(route('admin.business-type.destroy', $type->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button  style="border:0px;" class=""  onclick="return confirm('Are you sure you want to delete this business type?')"><i class="ri-delete-bin-fill align-bottom me-2 text-muted"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <!-- Pagination -->
        <div class="d-flex justify-content-between align-items-center mt-4">
            <div class="text-muted">
                Showing <?php echo e($businessTypes->firstItem() ?? 0); ?> to <?php echo e($businessTypes->lastItem() ?? 0); ?> of <?php echo e($businessTypes->total()); ?> results
            </div>
            
            <nav>
                <ul class="pagination mb-0">
                    
                    <?php if($businessTypes->onFirstPage()): ?>
                        <li class="page-item disabled"><span class="page-link">Previous</span></li>
                    <?php else: ?>
                        <li class="page-item">
                            <a class="page-link" href="<?php echo e($businessTypes->previousPageUrl()); ?><?php echo e(request()->getQueryString() ? '&' . http_build_query(request()->except('page')) : ''); ?>" rel="prev">Previous</a>
                        </li>
                    <?php endif; ?>

                    
                    <?php $__currentLoopData = $businessTypes->getUrlRange(1, $businessTypes->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $businessTypes->currentPage()): ?>
                            <li class="page-item active"><span class="page-link"><?php echo e($page); ?></span></li>
                        <?php else: ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e($url); ?><?php echo e(request()->getQueryString() ? '&' . http_build_query(request()->except('page')) : ''); ?>"><?php echo e($page); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    <?php if($businessTypes->hasMorePages()): ?>
                        <li class="page-item">
                            <a class="page-link" href="<?php echo e($businessTypes->nextPageUrl()); ?><?php echo e(request()->getQueryString() ? '&' . http_build_query(request()->except('page')) : ''); ?>" rel="next">Next</a>
                        </li>
                    <?php else: ?>
                        <li class="page-item disabled"><span class="page-link">Next</span></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\barbar\barbarshop\resources\views/admin/business-type/index.blade.php ENDPATH**/ ?>