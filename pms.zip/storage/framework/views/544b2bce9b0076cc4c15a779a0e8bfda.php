

<?php $__env->startSection('title','Create Package'); ?>

<?php $__env->startSection('content'); ?>

<h4>Create Package</h4>
<?php echo $__env->make('admin.layouts.error', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="card">
    <div class="card-body">
<form method="POST" action="<?php echo e(route('admin.package.store')); ?>">
    <?php echo csrf_field(); ?>

    <div class="mb-3">
        <label>Name</label>
        <input name="name" class="form-control" required />
    </div>

    <div class="mb-3">
        <label>Price</label>
        <input name="price" type="number" class="form-control" required />
    </div>

    <div class="mb-3">
        <label>Duration (days)</label>
        <input name="duration" type="number" class="form-control" required />
    </div>

    <button class="btn btn-dark">Save</button>
</form></div></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\barbar\barbarshop\resources\views/admin/package/create.blade.php ENDPATH**/ ?>