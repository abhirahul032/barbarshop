

<?php $__env->startSection('title', 'Business Type Details'); ?>

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between mb-3">
    <h4>Business Type Details</h4>
    <div>
        <a href="<?php echo e(route('admin.business-type.edit', $businessType->id)); ?>" class="btn btn-primary">Edit</a>
        <a href="<?php echo e(route('admin.business-type.index')); ?>" class="btn btn-secondary">Back to List</a>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-body">
                <table class="table table-bordered">
                    <tr>
                        <th width="200">ID</th>
                        <td><?php echo e($businessType->id); ?></td>
                    </tr>
                    <tr>
                        <th>Name</th>
                        <td><?php echo e($businessType->name); ?></td>
                    </tr>
                    <tr>
                        <th>Description</th>
                        <td><?php echo e($businessType->description ?? 'N/A'); ?></td>
                    </tr>
                    <tr>
                        <th>Status</th>
                        <td>
                            <?php if($businessType->is_active): ?>
                                <span class="badge bg-success">Active</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Inactive</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Created At</th>
                        <td><?php echo e($businessType->created_at->format('M d, Y H:i A')); ?></td>
                    </tr>
                    <tr>
                        <th>Updated At</th>
                        <td><?php echo e($businessType->updated_at->format('M d, Y H:i A')); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\barbar\barbarshop\resources\views/admin/business-type/view.blade.php ENDPATH**/ ?>