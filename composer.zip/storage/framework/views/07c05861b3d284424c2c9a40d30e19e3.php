

<?php $__env->startSection('title','Edit Package'); ?>

<?php $__env->startSection('content'); ?>

<h4>Edit Package</h4>

<form method="POST" action="<?php echo e(route('admin.package.update', $package->id)); ?>">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

    <div class="mb-3">
        <label>Name</label>
        <input name="name" value="<?php echo e($package->name); ?>" class="form-control" required />
    </div>

    <div class="mb-3">
        <label>Price</label>
        <input name="price" type="number" value="<?php echo e($package->price); ?>" class="form-control" required />
    </div>

    <div class="mb-3">
        <label>Duration (days)</label>
        <input name="duration" type="number" value="<?php echo e($package->duration); ?>" class="form-control" required />
    </div>

    <button class="btn btn-dark">Update</button>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\barbar\barbarshop\resources\views/admin/package/edit.blade.php ENDPATH**/ ?>