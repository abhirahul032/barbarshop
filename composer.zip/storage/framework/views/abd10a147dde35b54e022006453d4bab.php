

<?php $__env->startSection('title', 'Services'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Services</h4>
                    <a href="<?php echo e(route('store.services.create')); ?>" class="btn btn-primary">Add Service</a>
                </div>
                <div class="card-body">
                    <!-- Search and Filter Form -->
                    <form action="<?php echo e(route('store.services.index')); ?>" method="GET" class="mb-4">
                        <div class="row">
                            <div class="col-md-6">
                                <input type="text" name="search" class="form-control" placeholder="Search services..." value="<?php echo e(request('search')); ?>">
                            </div>
                            <div class="col-md-3">
                                <select name="category" class="form-control">
                                    <option value="">All Categories</option>
                                    <option value="hair" <?php echo e(request('category') == 'hair' ? 'selected' : ''); ?>>Hair</option>
                                    <option value="spa" <?php echo e(request('category') == 'spa' ? 'selected' : ''); ?>>Spa</option>
                                    <option value="coloring" <?php echo e(request('category') == 'coloring' ? 'selected' : ''); ?>>Coloring</option>
                                    <option value="beard" <?php echo e(request('category') == 'beard' ? 'selected' : ''); ?>>Beard</option>
                                    <option value="facial" <?php echo e(request('category') == 'facial' ? 'selected' : ''); ?>>Facial</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select name="status" class="form-control">
                                    <option value="">All Status</option>
                                    <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>Active</option>
                                    <option value="inactive" <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                                </select>
                            </div>
                        </div>
                        <div class="row mt-2">
                            <div class="col-md-6">
                                <button type="submit" class="btn btn-primary">Search</button>
                                <a href="<?php echo e(route('store.services.index')); ?>" class="btn btn-secondary">Reset</a>
                            </div>
                        </div>
                    </form>

                    <!-- Services Table -->
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>
                                        <a href="<?php echo e(route('store.services.index', ['sort' => 'name', 'direction' => request('direction') == 'asc' ? 'desc' : 'asc'] + request()->except('sort', 'direction'))); ?>">
                                            Service Name
                                            <?php if(request('sort') == 'name'): ?>
                                                <i class="fas fa-sort-<?php echo e(request('direction') == 'asc' ? 'up' : 'down'); ?>"></i>
                                            <?php endif; ?>
                                        </a>
                                    </th>
                                    <th>Description</th>
                                    <th>
                                        <a href="<?php echo e(route('store.services.index', ['sort' => 'category', 'direction' => request('direction') == 'asc' ? 'desc' : 'asc'] + request()->except('sort', 'direction'))); ?>">
                                            Category
                                            <?php if(request('sort') == 'category'): ?>
                                                <i class="fas fa-sort-<?php echo e(request('direction') == 'asc' ? 'up' : 'down'); ?>"></i>
                                            <?php endif; ?>
                                        </a>
                                    </th>
                                    <th>
                                        <a href="<?php echo e(route('store.services.index', ['sort' => 'price', 'direction' => request('direction') == 'asc' ? 'desc' : 'asc'] + request()->except('sort', 'direction'))); ?>">
                                            Price
                                            <?php if(request('sort') == 'price'): ?>
                                                <i class="fas fa-sort-<?php echo e(request('direction') == 'asc' ? 'up' : 'down'); ?>"></i>
                                            <?php endif; ?>
                                        </a>
                                    </th>
                                    <th>Duration</th>
                                    <th>Employees</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <strong><?php echo e($service->name); ?></strong>
                                    </td>
                                    <td>
                                        <?php if($service->description): ?>
                                            <span title="<?php echo e($service->description); ?>">
                                                <?php echo e(Str::limit($service->description, 50)); ?>

                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted">No description</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-info text-capitalize"><?php echo e($service->category); ?></span>
                                    </td>
                                    <td>
                                        <strong>$<?php echo e(number_format($service->price, 2)); ?></strong>
                                    </td>
                                    <td>
                                        <span class="badge bg-secondary"><?php echo e($service->duration_minutes); ?> minutes</span>
                                    </td>
                                    <td>
                                        <?php
                                            $employeeCount = $service->employees()->count();
                                        ?>
                                        <?php if($employeeCount > 0): ?>
                                            <span class="badge bg-success"><?php echo e($employeeCount); ?> employees</span>
                                        <?php else: ?>
                                            <span class="badge bg-warning">No employees</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo e($service->is_active ? 'success' : 'danger'); ?>">
                                            <?php echo e($service->is_active ? 'Active' : 'Inactive'); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('store.services.show', $service)); ?>" class=""><i class="ri-eye-fill align-bottom me-2 text-muted"></i></a>
                                            <a href="<?php echo e(route('store.services.edit', $service)); ?>" class=""><i class="ri-pencil-fill align-bottom me-2 text-muted"></i></a>
                                            <form action="<?php echo e(route('store.services.destroy', $service)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" style="border:0px;" class=""  onclick="return confirm('Are you sure you want to delete this service?')"><i class="ri-delete-bin-fill align-bottom me-2 text-muted"></i></button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    
                    <div class="d-flex justify-content-between align-items-center mt-4">
            <div class="text-muted">
                Showing <?php echo e($services->firstItem() ?? 0); ?> to <?php echo e($services->lastItem() ?? 0); ?> of <?php echo e($services->total()); ?> results
            </div>
            
            <nav>
                <ul class="pagination mb-0">
                    
                    <?php if($services->onFirstPage()): ?>
                        <li class="page-item disabled"><span class="page-link">Previous</span></li>
                    <?php else: ?>
                        <li class="page-item">
                            <a class="page-link" href="<?php echo e($services->previousPageUrl()); ?><?php echo e(request()->getQueryString() ? '&' . http_build_query(request()->except('page')) : ''); ?>" rel="prev">Previous</a>
                        </li>
                    <?php endif; ?>

                    
                    <?php $__currentLoopData = $services->getUrlRange(1, $services->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $services->currentPage()): ?>
                            <li class="page-item active"><span class="page-link"><?php echo e($page); ?></span></li>
                        <?php else: ?>
                            <li class="page-item">
                                <a class="page-link" href="<?php echo e($url); ?><?php echo e(request()->getQueryString() ? '&' . http_build_query(request()->except('page')) : ''); ?>"><?php echo e($page); ?></a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    <?php if($services->hasMorePages()): ?>
                        <li class="page-item">
                            <a class="page-link" href="<?php echo e($services->nextPageUrl()); ?><?php echo e(request()->getQueryString() ? '&' . http_build_query(request()->except('page')) : ''); ?>" rel="next">Next</a>
                        </li>
                    <?php else: ?>
                        <li class="page-item disabled"><span class="page-link">Next</span></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
                    
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('store.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\barbar\barbarshop\resources\views/store/services/index.blade.php ENDPATH**/ ?>