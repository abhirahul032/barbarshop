

<?php $__env->startSection('title', 'Store Details'); ?>

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between mb-3">
    <h4>Store Details</h4>
    <div>
        <a href="<?php echo e(route('admin.store.edit', $store->id)); ?>" class="btn btn-primary">Edit</a>
        <a href="<?php echo e(route('admin.store.index')); ?>" class="btn btn-secondary">Back to List</a>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-body">
                <table class="table table-bordered">
                    <tr>
                        <th width="200">ID</th>
                        <td><?php echo e($store->id); ?></td>
                    </tr>
                    <tr>
                        <th>Name</th>
                        <td><?php echo e($store->name); ?></td>
                    </tr>
                    <tr>
                        <th>URL</th>
                        <td>
                            <a href="<?php echo e($store->url); ?>" target="_blank" class="text-decoration-none">
                                <?php echo e($store->url); ?>

                            </a>
                        </td>
                    </tr>
                    <tr>
                        <th>Email</th>
                        <td><?php echo e($store->email); ?></td>
                    </tr>
                    <tr>
                        <th>Number of Employees</th>
                        <td><?php echo e($store->no_of_employees); ?></td>
                    </tr>
                    <tr>
                        <th>Package</th>
                        <td>
                            <span class="badge bg-primary"><?php echo e($store->package->name); ?></span>
                        </td>
                    </tr>


                    <tr>
                        <th>Billing Period</th>
                        <td>
                            <span class="badge bg-<?php echo e($store->billing_period == 'monthly' ? 'info' : 'warning'); ?>">
                                <?php echo e(ucfirst($store->billing_period)); ?>

                            </span>
                        </td>
                    </tr>
                    <tr>
                        <th>Start Date</th>
                        <td><?php echo e($store->start_date ? $store->start_date->format('M d, Y') : 'N/A'); ?></td>
                    </tr>
                    <tr>
                        <th>End Date</th>
                        <td><?php echo e($store->end_date ? $store->end_date->format('M d, Y') : 'N/A'); ?></td>
                    </tr>
                    <tr>
                        <th>Business Types</th>
                        <td>
                            <?php $__currentLoopData = $store->businessTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $businessType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge bg-primary mb-1"><?php echo e($businessType->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>

                    <tr>
                        <th>Created At</th>
                        <td><?php echo e($store->created_at->format('M d, Y H:i A')); ?></td>
                    </tr>
                    <tr>
                        <th>Updated At</th>
                        <td><?php echo e($store->updated_at->format('M d, Y H:i A')); ?></td>
                    </tr>



                </table>
            </div>
        </div>
    </div>
    
    <div class="col-md-4">
        <div class="card">
            <div class="card-body text-center">
                <h5 class="card-title">Store Logo</h5>
                <?php if($store->logo): ?>
                    <img src="<?php echo e(asset('storage/' . $store->logo)); ?>" 
                         class="img-fluid rounded" 
                         style="max-height: 200px; object-fit: cover;"
                         alt="<?php echo e($store->name); ?> logo">
                <?php else: ?>
                    <div class="text-muted py-4">
                        <i class="fas fa-store fa-3x mb-2"></i>
                        <p>No logo uploaded</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\barbar\barbarshop\resources\views/admin/store/view.blade.php ENDPATH**/ ?>