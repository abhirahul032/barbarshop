

<?php $__env->startSection('title', 'Employee Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Employee Details</h4>
                    <div>
                        <a href="<?php echo e(route('store.employees.edit', $employee)); ?>" class="btn btn-primary">Edit Employee</a>
                        <a href="<?php echo e(route('store.employees.index')); ?>" class="btn btn-secondary">Back to List</a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4 text-center">
                            <?php if($employee->photo): ?>
                                <img src="<?php echo e(asset('storage/' . $employee->photo)); ?>" class="img-fluid rounded-circle mb-3" width="200" height="200" style="object-fit: cover;" alt="<?php echo e($employee->name); ?> photo">
                            <?php else: ?>
                                <div class="bg-secondary rounded-circle d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 200px; height: 200px;">
                                    <i class="fas fa-user text-white" style="font-size: 80px;"></i>
                                </div>
                            <?php endif; ?>
                            <h3><?php echo e($employee->name); ?></h3>
                            <span class="badge bg-<?php echo e($employee->status == 'active' ? 'success' : ($employee->status == 'inactive' ? 'warning' : 'danger')); ?> fs-6">
                                <?php echo e(ucfirst($employee->status)); ?>

                            </span>
                        </div>

                        <div class="col-md-8">
                            <div class="row">
                                <div class="col-md-6">
                                    <h5>Personal Information</h5>
                                    <table class="table table-borderless">
                                        <tr>
                                            <th width="40%">Email:</th>
                                            <td><?php echo e($employee->email); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Phone:</th>
                                            <td><?php echo e($employee->phone); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Address:</th>
                                            <td><?php echo e($employee->address); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Date of Birth:</th>
                                            <td><?php echo e(\Carbon\Carbon::parse($employee->date_of_birth)->format('M d, Y')); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Age:</th>
                                            <td><?php echo e(\Carbon\Carbon::parse($employee->date_of_birth)->age); ?> years</td>
                                        </tr>
                                    </table>
                                </div>

                                <div class="col-md-6">
                                    <h5>Employment Details</h5>
                                    <table class="table table-borderless">
                                        <tr>
                                            <th width="40%">Employment Type:</th>
                                            <td><?php echo e(ucfirst(str_replace('_', ' ', $employee->employment_type))); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Hire Date:</th>
                                            <td><?php echo e(\Carbon\Carbon::parse($employee->hire_date)->format('M d, Y')); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Working Hours:</th>
                                            <td><?php echo e(\Carbon\Carbon::parse($employee->start_time)->format('h:i A')); ?> - <?php echo e(\Carbon\Carbon::parse($employee->end_time)->format('h:i A')); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Salary Per Hour:</th>
                                            <td>$<?php echo e(number_format($employee->salary_per_hour, 2)); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Working Days:</th>
                                            <td>
                                                <?php $__currentLoopData = $employee->working_days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="badge bg-primary me-1"><?php echo e(ucfirst($day)); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>

                            <div class="row mt-4">
                                <div class="col-md-6">
                                    <h5>Emergency Contact</h5>
                                    <table class="table table-borderless">
                                        <tr>
                                            <th width="40%">Contact Name:</th>
                                            <td><?php echo e($employee->emergency_contact_name); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Contact Phone:</th>
                                            <td><?php echo e($employee->emergency_contact_phone); ?></td>
                                        </tr>
                                    </table>
                                </div>

                                <div class="col-md-6">
                                    <h5>Additional Information</h5>
                                    <table class="table table-borderless">
                                        <tr>
                                            <th width="40%">Specialization:</th>
                                            <td><?php echo e($employee->specialization ?? 'N/A'); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Bank Details:</th>
                                            <td><?php echo e($employee->bank_account_details ?? 'N/A'); ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>

                            <?php if($employee->services->count() > 0): ?>
                            <div class="row mt-4">
                                <div class="col-md-12">
                                    <h5>Services Provided</h5>
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>Service Name</th>
                                                    <th>Price</th>
                                                    <th>Duration</th>
                                                    <th>Expertise Level</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $employee->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($service->name); ?></td>
                                                    <td>$<?php echo e(number_format($service->price, 2)); ?></td>
                                                    <td><?php echo e($service->duration_minutes); ?> minutes</td>
                                                    <td>
                                                        <?php
                                                            $expertiseLevel = $service->pivot->expertise_level ?? 1;
                                                        ?>
                                                        <div class="d-flex align-items-center">
                                                            <div class="progress flex-grow-1 me-2" style="height: 10px;">
                                                                <div class="progress-bar" role="progressbar" style="width: <?php echo e(($expertiseLevel / 5) * 100); ?>%"></div>
                                                            </div>
                                                            <span><?php echo e($expertiseLevel); ?>/5</span>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('store.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\barbar\barbarshop\resources\views/store/employees/show.blade.php ENDPATH**/ ?>