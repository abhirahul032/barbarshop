

<?php $__env->startSection('title', 'Edit Employee'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0">Edit Employee</h4>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('store.employees.update', $employee)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <h5>Personal Information</h5>
                                <div class="mb-3">
                                    <label for="name" class="form-label">Full Name *</label>
                                    <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name', $employee->name)); ?>" required>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="email" class="form-label">Email *</label>
                                            <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email', $employee->email)); ?>" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="phone" class="form-label">Phone *</label>
                                            <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e(old('phone', $employee->phone)); ?>" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="address" class="form-label">Address *</label>
                                    <textarea class="form-control" id="address" name="address" rows="3" required><?php echo e(old('address', $employee->address)); ?></textarea>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="date_of_birth" class="form-label">Date of Birth *</label>
                                            <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" 

                                                   value="<?php echo e(old('date_of_birth', \Carbon\Carbon::parse($employee->start_time)->format('Y-m-d'))); ?>"
                                                   
                                                   required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="photo" class="form-label">Photo</label>
                                            <input type="file" class="form-control" id="photo" name="photo">
                                            <?php if($employee->photo): ?>
                                                <div class="mt-2">
                                                    <img src="<?php echo e(asset('storage/' . $employee->photo)); ?>" width="100" height="100" style="object-fit: cover;" alt="Current photo">
                                                    <p class="text-muted small">Current photo</p>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <h5>Employment Details</h5>
                                 <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="hire_date" class="form-label">Hire Date *</label>
                                            <input type="date" class="form-control" id="hire_date" name="hire_date" 
                                                  
                                                   value="<?php echo e(old('hire_date', \Carbon\Carbon::parse($employee->start_time)->format('Y-m-d'))); ?>"
                                                   required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="employment_type" class="form-label">Employment Type *</label>
                                            <select class="form-control" id="employment_type" name="employment_type" required>
                                                <option value="full_time" <?php echo e(old('employment_type', $employee->employment_type) == 'full_time' ? 'selected' : ''); ?>>Full Time</option>
                                                <option value="part_time" <?php echo e(old('employment_type', $employee->employment_type) == 'part_time' ? 'selected' : ''); ?>>Part Time</option>
                                                <option value="contract" <?php echo e(old('employment_type', $employee->employment_type) == 'contract' ? 'selected' : ''); ?>>Contract</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="start_time" class="form-label">Start Time *</label>
                                            <input type="time" class="form-control" id="start_time" name="start_time" value="<?php echo e(old('start_time', \Carbon\Carbon::parse($employee->start_time)->format('H:i'))); ?>" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="end_time" class="form-label">End Time *</label>
                                            <input type="time" class="form-control" id="end_time" name="end_time" value="<?php echo e(old('end_time', \Carbon\Carbon::parse($employee->end_time)->format('H:i'))); ?>" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="salary_per_hour" class="form-label">Salary Per Hour ($) *</label>
                                    <input type="number" step="0.01" class="form-control" id="salary_per_hour" name="salary_per_hour" value="<?php echo e(old('salary_per_hour', $employee->salary_per_hour)); ?>" required>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Working Days *</label>
                                    <div class="row">
                                        <?php $__currentLoopData = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-4">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="working_days[]" value="<?php echo e($day); ?>" id="<?php echo e($day); ?>" 
                                                    <?php echo e(in_array($day, old('working_days', $employee->working_days ?? [])) ? 'checked' : ''); ?>>
                                                <label class="form-check-label" for="<?php echo e($day); ?>">
                                                    <?php echo e(ucfirst($day)); ?>

                                                </label>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>

                                <div class="mb-3">
                                    <label for="status" class="form-label">Status *</label>
                                    <select class="form-control" id="status" name="status" required>
                                        <option value="active" <?php echo e(old('status', $employee->status) == 'active' ? 'selected' : ''); ?>>Active</option>
                                        <option value="inactive" <?php echo e(old('status', $employee->status) == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                                        <option value="suspended" <?php echo e(old('status', $employee->status) == 'suspended' ? 'selected' : ''); ?>>Suspended</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <div class="col-md-6">
                                <h5>Emergency Contact</h5>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="emergency_contact_name" class="form-label">Contact Name *</label>
                                            <input type="text" class="form-control" id="emergency_contact_name" name="emergency_contact_name" value="<?php echo e(old('emergency_contact_name', $employee->emergency_contact_name)); ?>" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="emergency_contact_phone" class="form-label">Contact Phone *</label>
                                            <input type="text" class="form-control" id="emergency_contact_phone" name="emergency_contact_phone" value="<?php echo e(old('emergency_contact_phone', $employee->emergency_contact_phone)); ?>" required>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <h5>Additional Information</h5>
                                <div class="mb-3">
                                    <label for="specialization" class="form-label">Specialization</label>
                                    <input type="text" class="form-control" id="specialization" name="specialization" value="<?php echo e(old('specialization', $employee->specialization)); ?>" placeholder="e.g., Hair Coloring, Beard Styling">
                                </div>

                                <div class="mb-3">
                                    <label for="bank_account_details" class="form-label">Bank Account Details</label>
                                    <textarea class="form-control" id="bank_account_details" name="bank_account_details" rows="2"><?php echo e(old('bank_account_details', $employee->bank_account_details)); ?></textarea>
                                </div>
                            </div>
                        </div>

                        <!-- Services Provided Section -->
                        <div class="row mt-3">
                            <div class="col-md-12">
                                <h5>Services Provided</h5>
                                <div id="services-container">
                                    <?php if($services->count() > 0): ?>
                                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="row mb-2 service-row">
                                            <div class="col-md-6">
                                                <div class="form-check">
                                                    <?php
                                                        $employeeService = $employee->services->where('id', $service->id)->first();
                                                        $isChecked = $employeeService ? 'checked' : '';
                                                        $expertiseLevel = $employeeService ? $employeeService->pivot->expertise_level : 3;
                                                    ?>
                                                    <input class="form-check-input service-checkbox" type="checkbox" name="services[]" value="<?php echo e($service->id); ?>" id="service_<?php echo e($service->id); ?>" <?php echo e($isChecked); ?>>
                                                    <label class="form-check-label" for="service_<?php echo e($service->id); ?>">
                                                        <?php echo e($service->name); ?> ($<?php echo e(number_format($service->price, 2)); ?> - <?php echo e($service->duration_minutes); ?>min)
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <label>Expertise Level (1-5)</label>
                                                <input type="number" class="form-control expertise-level" name="expertise_levels[]" min="1" max="5" value="<?php echo e($expertiseLevel); ?>" <?php echo e($isChecked ? '' : 'disabled'); ?>>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <p class="text-muted">No services available. <a href="<?php echo e(route('store.services.create')); ?>">Create services first</a>.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="mt-4">
                            <button type="submit" class="btn btn-primary">Update Employee</button>
                            <a href="<?php echo e(route('store.employees.index')); ?>" class="btn btn-secondary">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const serviceCheckboxes = document.querySelectorAll('.service-checkbox');
    
    serviceCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const expertiseInput = this.closest('.service-row').querySelector('.expertise-level');
            expertiseInput.disabled = !this.checked;
            if (!this.checked) {
                expertiseInput.value = '3';
            }
        });
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('store.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\barbar\barbarshop\resources\views/store/employees/edit.blade.php ENDPATH**/ ?>