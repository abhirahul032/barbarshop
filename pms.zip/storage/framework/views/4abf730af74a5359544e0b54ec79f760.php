

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

    <?php $user = auth()->user(); ?>
    <h3>Welcome, <?php echo $user->name ?>!</h3>
    <?php //echo '<pre>'; print_r($user); echo '</pre>'; ?>
    <p>Your admin dashboard is ready.</p>
    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('store.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\barbar\barbarshop\resources\views/store/dashboard.blade.php ENDPATH**/ ?>