

<?php $__env->startSection('title', 'Employees'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Employees</h4>
                    <a href="<?php echo e(route('store.employees.create')); ?>" class="btn btn-primary">Add Employee</a>
                </div>
                <div class="card-body">
                    <!-- Search and Filter Form -->
                    <form action="<?php echo e(route('store.employees.index')); ?>" method="GET" class="mb-4">
                        <div class="row">
                            <div class="col-md-6">
                                <input type="text" name="search" class="form-control" placeholder="Search store.employees..." value="<?php echo e(request('search')); ?>">
                            </div>
                            <div class="col-md-3">
                                <select name="status" class="form-control">
                                    <option value="">All Status</option>
                                    <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>Active</option>
                                    <option value="inactive" <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <button type="submit" class="btn btn-primary">Search</button>
                                <a href="<?php echo e(route('store.employees.index')); ?>" class="btn btn-secondary">Reset</a>
                            </div>
                        </div>
                    </form>

                    <!-- Employees Table -->
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>
                                        <a href="<?php echo e(route('store.employees.index', ['sort' => 'name', 'direction' => request('direction') == 'asc' ? 'desc' : 'asc'] + request()->except('sort', 'direction'))); ?>">
                                            Name
                                            <?php if(request('sort') == 'name'): ?>
                                                <i class="fas fa-sort-<?php echo e(request('direction') == 'asc' ? 'up' : 'down'); ?>"></i>
                                            <?php endif; ?>
                                        </a>
                                    </th>
                                    <th>Contact</th>
                                    <th>Working Days</th>
                                    <th>Hours</th>
                                    <th>Salary/Hour</th>
                                    <th>Services</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <?php if($employee->photo): ?>                                               

                                            <img src="<?php echo e(asset('storage/' . $employee->photo)); ?>" width="50" height="50" style="object-fit: cover;" alt="<?php echo e($employee->name); ?> logo">

                                            <?php else: ?>
                                                <div class="bg-secondary rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 40px; height: 40px;">
                                                    <i class="fas fa-user text-white"></i>
                                                </div>
                                            <?php endif; ?>
                                            <div>
                                                <strong><?php echo e($employee->name); ?></strong>
                                                <br>
                                                <small class="text-muted"><?php echo e($employee->employment_type); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div><?php echo e($employee->email); ?></div>
                                        <small class="text-muted"><?php echo e($employee->phone); ?></small>
                                    </td>
                                    <td>
                                        <?php $__currentLoopData = $employee->working_days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge bg-primary"><?php echo e(ucfirst($day)); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e(\Carbon\Carbon::parse($employee->start_time)->format('h:i A')); ?> - <?php echo e(\Carbon\Carbon::parse($employee->end_time)->format('h:i A')); ?></td>
                                    <td>$<?php echo e(number_format($employee->salary_per_hour, 2)); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $employee->services->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge bg-info"><?php echo e($service->name); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($employee->services->count() > 3): ?>
                                            <span class="badge bg-secondary">+<?php echo e($employee->services->count() - 3); ?> more</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo e($employee->status == 'active' ? 'success' : ($employee->status == 'inactive' ? 'warning' : 'danger')); ?>">
                                            <?php echo e(ucfirst($employee->status)); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('store.employees.show', $employee)); ?>" ><i class="ri-eye-fill align-bottom me-2 text-muted"></i></a>
                                            <a href="<?php echo e(route('store.employees.edit', $employee)); ?>" ><i class="ri-pencil-fill align-bottom me-2 text-muted"></i></a>
                                            <form action="<?php echo e(route('store.employees.destroy', $employee)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit"  style="border:0px;" class="" onclick="return confirm('Are you sure?')"><i class="ri-delete-bin-fill align-bottom me-2 text-muted"></i></button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            Showing <?php echo e($employees->firstItem()); ?> to <?php echo e($employees->lastItem()); ?> of <?php echo e($employees->total()); ?> results
                        </div>
                        <?php echo e($employees->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('store.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\barbar\barbarshop\resources\views/store/employees/index.blade.php ENDPATH**/ ?>