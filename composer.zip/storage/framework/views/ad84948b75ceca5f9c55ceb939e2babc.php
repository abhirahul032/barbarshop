

<?php $__env->startSection('title', 'View Package'); ?>

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between mb-3">
    <h4>Package Details</h4>
    <div>
        <a href="<?php echo e(route('admin.package.edit', $package->id)); ?>" class="btn btn-primary">Edit</a>
        <a href="<?php echo e(route('admin.package.index')); ?>" class="btn btn-secondary">Back to List</a>
    </div>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <table class="table table-bordered">
            <tr>
                <th width="200">ID</th>
                <td><?php echo e($package->id); ?></td>
            </tr>
            <tr>
                <th>Name</th>
                <td><?php echo e($package->name); ?></td>
            </tr>
            <tr>
                <th>Price</th>
                <td>$<?php echo e(number_format($package->price, 2)); ?></td>
            </tr>
            <tr>
                <th>Duration (Days)</th>
                <td><?php echo e($package->duration); ?></td>
            </tr>
            <tr>
                <th>Created At</th>
                <td><?php echo e($package->created_at->format('M d, Y H:i A')); ?></td>
            </tr>
            <tr>
                <th>Updated At</th>
                <td><?php echo e($package->updated_at->format('M d, Y H:i A')); ?></td>
            </tr>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\barbar\barbarshop\resources\views/admin/package/view.blade.php ENDPATH**/ ?>