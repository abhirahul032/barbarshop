

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <h3>Welcome, Admin!</h3>
    <p>Your admin dashboard is ready.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\wamp64\www\barbar\barbarshop\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>